package HierarchicalInheritance.java;
import java.util.Scanner;
class Person {
    String name;
    public void getdata_person() {
        System.out.print("Enter your name:");
        Scanner sc = new Scanner(System.in);
        name = sc.nextLine();
    }
    public void display_person() {
        System.out.println("Your name is:" + name);
    }
}

class Education extends Person {
    String vname;
    public void getdata_education() {
        System.out.print("Hei " +name+ "!,"  + " Please enter your varsity name:");
        Scanner sc = new Scanner(System.in);
        vname = sc.nextLine();
    }
    public void display_education() {
        System.out.println("Varsity:" + vname);
    }
}

class Profession extends Person {
    String cname;
    public void getdata_programmer() {
        System.out.print("Enter your company name:");
        Scanner sc = new Scanner(System.in);
        cname = sc.nextLine();
    }
    public void display_programmer() {
        System.out.println("Company (Mr "+name+"): " + cname);
    }
}
public class Programmer extends Profession {

    public static void main(String args[]) {
		Programmer p = new Programmer();
		p.getdata_person();
		p.getdata_programmer();
		p.display_person();
		p.display_programmer();
    }
}
